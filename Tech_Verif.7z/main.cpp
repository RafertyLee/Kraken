#include "launch.h"
#include <iostream>
int main(void){
    std::cout << "launching" <<std::endl;
    void launch();
    return 0;
}